package logica;

public class Logica {

}
