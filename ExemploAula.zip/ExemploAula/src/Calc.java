
public class Calc {

	public int Somar(int a, int b){
		return a+b;
	}
	
	public int Diminuir(int a, int b){
		return a-b;
	}
	
	public String Copyright(){
		return "Feito por RL System";
	}
	
	//Overloading
}
