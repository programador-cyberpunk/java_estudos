
public interface IDb {
	void conectar();
	void desconectar();
}
