
public class Procedimentos {
	
	public static void Escrever(String texto){
		System.out.println(texto);
	}
	
}
