package br.com.rlsystem.carros;

import br.com.rlsystem.model.*;

public class C4 extends Veiculo {

}
