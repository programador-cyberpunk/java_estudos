package br.com.rlsystem.caminhoes;

public class Volvo {

}
