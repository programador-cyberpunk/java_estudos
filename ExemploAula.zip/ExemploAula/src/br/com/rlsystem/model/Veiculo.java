package br.com.rlsystem.model;

public class Veiculo {

	protected int velocidade_maxima;
}
